using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;
using TradeServer.Models;
using TradeServer.Config;

namespace TradeServer.Strategies
{
    public class StatisticalArbitrageStrategy
    {
        private readonly ILogger _logger;
        private readonly AppSettings _config;
        private readonly ConcurrentDictionary<string, PairState> _pairStates = new();
        private readonly ConcurrentDictionary<string, List<decimal>> _priceHistory = new();
        private readonly object _lockObject = new();

        public StatisticalArbitrageStrategy(ILogger<StatisticalArbitrageStrategy> logger, AppSettings config)
        {
            _logger = logger;
            _config = config;
        }

        public StrategyResult EvaluateOpportunity(MarketData marketData)
        {
            try
            {
                var opportunities = new List<ArbitrageOpportunity>();

                // Find correlated pairs and evaluate spread opportunities
                var symbols = marketData.Prices.Keys.ToList();
                
                for (int i = 0; i < symbols.Count; i++)
                {
                    for (int j = i + 1; j < symbols.Count; j++)
                    {
                        var symbol1 = symbols[i];
                        var symbol2 = symbols[j];
                        var pairKey = GetPairKey(symbol1, symbol2);

                        var opportunity = EvaluatePair(symbol1, symbol2, marketData, pairKey);
                        if (opportunity != null && opportunity.ExpectedReturn > _config.Strategy.MinExpectedReturn)
                        {
                            opportunities.Add(opportunity);
                        }
                    }
                }

                // Sort by expected return and select best opportunities
                var bestOpportunities = opportunities
                    .OrderByDescending(o => o.ExpectedReturn)
                    .Take(_config.Strategy.MaxConcurrentTrades)
                    .ToList();

                return new StrategyResult
                {
                    Success = bestOpportunities.Any(),
                    Opportunities = bestOpportunities,
                    Message = $"Found {bestOpportunities.Count} statistical arbitrage opportunities"
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[StatArb] Error evaluating opportunities");
                return new StrategyResult
                {
                    Success = false,
                    Message = $"Strategy evaluation failed: {ex.Message}"
                };
            }
        }

        private ArbitrageOpportunity? EvaluatePair(string symbol1, string symbol2, MarketData marketData, string pairKey)
        {
            if (!marketData.Prices.TryGetValue(symbol1, out var price1) ||
                !marketData.Prices.TryGetValue(symbol2, out var price2))
                return null;

            var pairState = _pairStates.GetOrAdd(pairKey, _ => new PairState());
            
            // Update price history
            UpdatePriceHistory(symbol1, price1);
            UpdatePriceHistory(symbol2, price2);

            // Calculate spread and z-score
            var spread = CalculateSpread(price1, price2, pairState);
            var zScore = CalculateZScore(spread, pairState);

            // Update pair state
            pairState.UpdateSpread(spread);
            pairState.LastUpdate = DateTimeOffset.UtcNow;

            // Check for mean reversion opportunity
            if (Math.Abs(zScore) > _config.Strategy.ZScoreThreshold)
            {
                var direction = zScore > 0 ? -1 : 1; // Mean reversion: bet against extreme moves
                var confidence = Math.Min(Math.Abs(zScore) / 3.0, 1.0); // Cap confidence at 1.0
                
                var expectedReturn = CalculateExpectedReturn(zScore, pairState);
                var riskScore = CalculateRiskScore(pairState);

                if (expectedReturn > 0 && riskScore < _config.Strategy.MaxRiskScore)
                {
                    return new ArbitrageOpportunity
                    {
                        Type = "StatisticalArbitrage",
                        Symbol1 = symbol1,
                        Symbol2 = symbol2,
                        Price1 = price1,
                        Price2 = price2,
                        Direction = direction,
                        Confidence = confidence,
                        ExpectedReturn = expectedReturn,
                        RiskScore = riskScore,
                        ZScore = zScore,
                        Spread = spread,
                        TimestampMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                        ExpiryMs = DateTimeOffset.UtcNow.AddSeconds(_config.Strategy.OpportunityTtlSeconds).ToUnixTimeMilliseconds()
                    };
                }
            }

            return null;
        }

        private decimal CalculateSpread(decimal price1, decimal price2, PairState pairState)
        {
            // Use log spread for better statistical properties
            var logPrice1 = (decimal)Math.Log((double)price1);
            var logPrice2 = (decimal)Math.Log((double)price2);
            
            // Calculate hedge ratio if we have enough history
            var hedgeRatio = pairState.HedgeRatio > 0 ? pairState.HedgeRatio : 1.0m;
            
            return logPrice1 - (hedgeRatio * logPrice2);
        }

        private double CalculateZScore(decimal spread, PairState pairState)
        {
            if (pairState.SpreadHistory.Count < 20) // Need minimum history
                return 0;

            var mean = pairState.SpreadHistory.Average();
            var variance = pairState.SpreadHistory.Sum(s => Math.Pow((double)(s - mean), 2)) / pairState.SpreadHistory.Count;
            var stdDev = Math.Sqrt(variance);

            if (stdDev == 0) return 0;

            return (double)(spread - mean) / stdDev;
        }

        private double CalculateExpectedReturn(double zScore, PairState pairState)
        {
            // Expected return based on mean reversion strength and historical performance
            var meanReversionStrength = Math.Min(Math.Abs(zScore) / 2.0, 1.0);
            var historicalSuccessRate = pairState.SuccessfulTrades / Math.Max(1.0, pairState.TotalTrades);
            
            return meanReversionStrength * historicalSuccessRate * _config.Strategy.BaseExpectedReturn;
        }

        private double CalculateRiskScore(PairState pairState)
        {
            // Risk based on spread volatility and recent performance
            if (pairState.SpreadHistory.Count < 10)
                return 1.0; // High risk for insufficient data

            var spreadVolatility = CalculateVolatility(pairState.SpreadHistory);
            var recentPerformance = pairState.RecentWinRate;
            
            return spreadVolatility * (1.0 - recentPerformance);
        }

        private double CalculateVolatility(List<decimal> values)
        {
            if (values.Count < 2) return 1.0;

            var mean = values.Average();
            var variance = values.Sum(v => Math.Pow((double)(v - mean), 2)) / values.Count;
            
            return Math.Sqrt(variance);
        }

        private void UpdatePriceHistory(string symbol, decimal price)
        {
            lock (_lockObject)
            {
                var history = _priceHistory.GetOrAdd(symbol, _ => new List<decimal>());
                history.Add(price);
                
                // Keep only recent history
                if (history.Count > _config.Strategy.MaxPriceHistory)
                {
                    history.RemoveAt(0);
                }
            }
        }

        private string GetPairKey(string symbol1, string symbol2)
        {
            // Ensure consistent ordering
            return string.Compare(symbol1, symbol2) < 0 ? $"{symbol1}_{symbol2}" : $"{symbol2}_{symbol1}";
        }

        public void UpdateTradeResult(string pairKey, bool success, double actualReturn)
        {
            if (_pairStates.TryGetValue(pairKey, out var pairState))
            {
                pairState.RecordTrade(success, actualReturn);
                _logger.LogInformation("[StatArb] Trade result for {PairKey}: Success={Success}, Return={Return:F4}", 
                    pairKey, success, actualReturn);
            }
        }

        public Dictionary<string, PairStatistics> GetPairStatistics()
        {
            var stats = new Dictionary<string, PairStatistics>();
            
            foreach (var kvp in _pairStates)
            {
                var pairState = kvp.Value;
                stats[kvp.Key] = new PairStatistics
                {
                    PairKey = kvp.Key,
                    TotalTrades = pairState.TotalTrades,
                    SuccessfulTrades = pairState.SuccessfulTrades,
                    WinRate = pairState.TotalTrades > 0 ? pairState.SuccessfulTrades / pairState.TotalTrades : 0,
                    AverageReturn = pairState.AverageReturn,
                    CurrentSpread = pairState.CurrentSpread,
                    SpreadVolatility = CalculateVolatility(pairState.SpreadHistory),
                    LastUpdate = pairState.LastUpdate
                };
            }
            
            return stats;
        }
    }

    public class PairState
    {
        public List<decimal> SpreadHistory { get; } = new();
        public decimal HedgeRatio { get; set; } = 1.0m;
        public decimal CurrentSpread { get; private set; }
        public double TotalTrades { get; set; }
        public double SuccessfulTrades { get; set; }
        public double AverageReturn { get; set; }
        public DateTimeOffset LastUpdate { get; set; }
        
        private readonly Queue<bool> _recentResults = new();
        private readonly object _lock = new();

        public double RecentWinRate
        {
            get
            {
                lock (_lock)
                {
                    return _recentResults.Count > 0 ? _recentResults.Count(r => r) / (double)_recentResults.Count : 0.5;
                }
            }
        }

        public void UpdateSpread(decimal spread)
        {
            CurrentSpread = spread;
            SpreadHistory.Add(spread);
            
            // Keep limited history
            if (SpreadHistory.Count > 200)
                SpreadHistory.RemoveAt(0);
        }

        public void RecordTrade(bool success, double actualReturn)
        {
            lock (_lock)
            {
                TotalTrades++;
                if (success) SuccessfulTrades++;
                
                // Update average return
                AverageReturn = ((AverageReturn * (TotalTrades - 1)) + actualReturn) / TotalTrades;
                
                // Update recent results
                _recentResults.Enqueue(success);
                if (_recentResults.Count > 20)
                    _recentResults.Dequeue();
            }
        }
    }

    public class PairStatistics
    {
        public string PairKey { get; set; } = string.Empty;
        public double TotalTrades { get; set; }
        public double SuccessfulTrades { get; set; }
        public double WinRate { get; set; }
        public double AverageReturn { get; set; }
        public decimal CurrentSpread { get; set; }
        public double SpreadVolatility { get; set; }
        public DateTimeOffset LastUpdate { get; set; }
    }
}
