#!/bin/bash

# Simple script to push corrected build to existing GitHub repository
# Usage: ./push-to-existing-repo.sh <repository-url>

set -e

if [ $# -eq 0 ]; then
    echo "Usage: $0 <repository-url>"
    echo "Example: $0 https://github.com/username/repository-name.git"
    exit 1
fi

REPO_URL="$1"

echo "=== Pushing Corrected TradeServer Build ==="
echo "Repository: $REPO_URL"
echo "Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"

# Add remote if not exists
if ! git remote get-url origin >/dev/null 2>&1; then
    echo "Adding remote origin..."
    git remote add origin "$REPO_URL"
else
    echo "Updating remote origin..."
    git remote set-url origin "$REPO_URL"
fi

# Ensure we're on main branch
git checkout main 2>/dev/null || git checkout -b main

# Add all files
echo "Adding corrected files..."
git add .

# Commit if there are changes
if ! git diff --staged --quiet; then
    echo "Committing corrected build..."
    git commit -m "🔧 CORRECTED BUILD: Fixed GitHub Actions and deployment issues

✅ FIXES APPLIED:
- Fixed GitHub Actions directory creation error
- Resolved dependency injection issues (ILogger -> ILogger<T>)
- Maintained nanosecond precision for low-latency trading
- Corrected YAML syntax and workflow structure
- Added comprehensive error handling

🚀 READY FOR DEPLOYMENT:
- Complete 7-layer risk management system
- Statistical arbitrage with z-score analysis  
- Performance optimization with memory pooling
- Comprehensive monitoring and health checks
- Production-ready deployment scripts

📦 ARTIFACTS INCLUDED:
- tradeserver-deployment-final.tar.gz (complete package)
- Fixed GitHub Actions workflow
- Deployment scripts and documentation
- Production and development configurations

Build timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)
Previous issues: RESOLVED ✅"
else
    echo "No changes to commit"
fi

# Push to GitHub
echo "Pushing to GitHub..."
git push -u origin main

echo ""
echo "✅ SUCCESS! Corrected build pushed to GitHub"
echo "🚀 GitHub Actions will now run with the fixed workflow"
echo ""
echo "Monitor deployment at:"
echo "$(echo "$REPO_URL" | sed 's/\.git$//')/actions"
echo ""
echo "The corrected workflow will:"
echo "  ✅ Create proper log directories"
echo "  ✅ Build with nanosecond precision maintained"
echo "  ✅ Deploy to configured servers"
echo "  ✅ Capture and analyze runtime logs"
echo "  ✅ Create deployment artifacts"
