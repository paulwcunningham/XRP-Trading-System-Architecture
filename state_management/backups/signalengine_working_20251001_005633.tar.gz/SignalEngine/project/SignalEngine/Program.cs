using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using TradeServer.Config;
using TradeServer.Risk;
using TradeServer.Validation;
using TradeServer.Strategies;
using TradeServer.Performance;
using TradeServer.TradeServer;

namespace SignalEngine
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Console.WriteLine($"[{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss}] Starting SignalEngine...");
            
            try
            {
                var host = CreateHostBuilder(args).Build();
                
                // Log startup information
                var logger = host.Services.GetRequiredService<ILogger<Program>>();
                var config = host.Services.GetRequiredService<AppSettings>();
                
                logger.LogInformation("SignalEngine starting with configuration:");
                logger.LogInformation("- Environment: {Environment}", Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development");
                logger.LogInformation("- Risk Kill Switch: {KillSwitch}", config.Risk.KillSwitch);
                logger.LogInformation("- Max Notional Per Order: {MaxNotional:C}", config.Risk.MaxNotionalPerOrder);
                logger.LogInformation("- Signal TTL: {SignalTtl}ms", config.Risk.SignalTtlMs);
                logger.LogInformation("- Enabled Strategies: StatArb={StatArb}, TriArb={TriArb}, MeanRev={MeanRev}", 
                    config.Strategy.EnableStatisticalArbitrage,
                    config.Strategy.EnableTriangularArbitrage,
                    config.Strategy.EnableMeanReversion);
                
                // Start the application
                await host.RunAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss}] Fatal error during startup: {ex}");
                Environment.Exit(1);
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((context, config) =>
                {
                    var env = context.HostingEnvironment;
                    
                    config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                          .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                          .AddEnvironmentVariables()
                          .AddCommandLine(args);
                })
                .ConfigureLogging((context, logging) =>
                {
                    logging.ClearProviders();
                    
                    var loggingConfig = context.Configuration.GetSection("Logging").Get<LoggingSettings>() ?? new LoggingSettings();
                    
                    if (loggingConfig.EnableConsoleLogging)
                    {
                        logging.AddConsole(options =>
                        {
                            options.TimestampFormat = "[yyyy-MM-dd HH:mm:ss.fff] ";
                        });
                    }
                    
                    // Set log level
                    if (Enum.TryParse<LogLevel>(loggingConfig.LogLevel, out var logLevel))
                    {
                        logging.SetMinimumLevel(logLevel);
                    }
                    
                    // Add structured logging filters
                    logging.AddFilter("Microsoft", LogLevel.Warning);
                    logging.AddFilter("System", LogLevel.Warning);
                    logging.AddFilter("Microsoft.Hosting.Lifetime", LogLevel.Information);
                })
                .ConfigureServices((context, services) =>
                {
                    // Bind configuration
                    var appSettings = new AppSettings();
                    context.Configuration.Bind(appSettings);
                    services.AddSingleton(appSettings);
                    
                    // Register core services
                    services.AddSingleton<ProductionRiskEngine>();
                    services.AddSingleton<SignalQualityValidator>();
                    services.AddSingleton<StatisticalArbitrageStrategy>();
                    services.AddSingleton<PerformanceOptimizations>();
                    
                    // Register the main trading engine
                    services.AddHostedService<TradingEngineService>();
                    
                    // Add health checks
                    services.AddHealthChecks()
                        .AddCheck<TradingEngineHealthCheck>("trading_engine");
                });
    }
}
