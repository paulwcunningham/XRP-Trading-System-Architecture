using System.ComponentModel.DataAnnotations;

namespace TradeServer.Models
{
    public class TradingSignal
    {
        public string Symbol { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public decimal Direction { get; set; } // -1 for sell, +1 for buy
        public decimal Confidence { get; set; } // 0.0 to 1.0
        public long TimestampMs { get; set; }
        public string Source { get; set; } = string.Empty;
        public Dictionary<string, object> Metadata { get; set; } = new();
    }

    public class OrderCommand
    {
        public string ClientOrderId { get; set; } = string.Empty;
        public string Symbol { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public decimal Quantity { get; set; }
        public OrderSide Side { get; set; }
        public OrderType Type { get; set; }
        public long TsNanosSent { get; set; }
        public string Strategy { get; set; } = string.Empty;
        public Dictionary<string, object> Tags { get; set; } = new();
    }

    public class MarketData
    {
        public Dictionary<string, decimal> Prices { get; set; } = new();
        public Dictionary<string, decimal> Volumes { get; set; } = new();
        public Dictionary<string, OrderBook> OrderBooks { get; set; } = new();
        public long TimestampMs { get; set; }
        public string Source { get; set; } = string.Empty;
    }

    public class OrderBook
    {
        public List<PriceLevel> Bids { get; set; } = new();
        public List<PriceLevel> Asks { get; set; } = new();
        public long TimestampMs { get; set; }
        public string Symbol { get; set; } = string.Empty;
    }

    public class PriceLevel
    {
        public decimal Price { get; set; }
        public decimal Quantity { get; set; }
        public int OrderCount { get; set; }
    }

    public class ArbitrageOpportunity
    {
        public string Type { get; set; } = string.Empty; // "StatisticalArbitrage", "TriangularArbitrage", etc.
        public string Symbol1 { get; set; } = string.Empty;
        public string Symbol2 { get; set; } = string.Empty;
        public string? Symbol3 { get; set; } // For triangular arbitrage
        public decimal Price1 { get; set; }
        public decimal Price2 { get; set; }
        public decimal? Price3 { get; set; }
        public int Direction { get; set; } // 1 for long, -1 for short
        public double Confidence { get; set; }
        public double ExpectedReturn { get; set; }
        public double RiskScore { get; set; }
        public double ZScore { get; set; }
        public decimal Spread { get; set; }
        public long TimestampMs { get; set; }
        public long ExpiryMs { get; set; }
        public Dictionary<string, object> Metadata { get; set; } = new();
    }

    public class RiskValidationResult
    {
        public bool IsValid { get; set; }
        public string ReasonCode { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public Dictionary<string, object> Details { get; set; } = new();

        public static RiskValidationResult Approve(string message)
        {
            return new RiskValidationResult
            {
                IsValid = true,
                ReasonCode = "approved",
                Message = message
            };
        }

        public static RiskValidationResult Reject(string reasonCode, string message)
        {
            return new RiskValidationResult
            {
                IsValid = false,
                ReasonCode = reasonCode,
                Message = message
            };
        }
    }

    public class SignalValidationResult
    {
        public bool IsValid { get; set; }
        public string ReasonCode { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public Dictionary<string, object> Details { get; set; } = new();

        public static SignalValidationResult Approve(string message)
        {
            return new SignalValidationResult
            {
                IsValid = true,
                ReasonCode = "approved",
                Message = message
            };
        }

        public static SignalValidationResult Reject(string reasonCode, string message)
        {
            return new SignalValidationResult
            {
                IsValid = false,
                ReasonCode = reasonCode,
                Message = message
            };
        }
    }

    public class StrategyResult
    {
        public bool Success { get; set; }
        public List<ArbitrageOpportunity> Opportunities { get; set; } = new();
        public string Message { get; set; } = string.Empty;
        public Dictionary<string, object> Metrics { get; set; } = new();
    }

    public class PerformanceMetrics
    {
        public double LatencyMicroseconds { get; set; }
        public double ThroughputPerSecond { get; set; }
        public double CpuUsagePercent { get; set; }
        public double MemoryUsageMB { get; set; }
        public long MessagesProcessed { get; set; }
        public long ErrorCount { get; set; }
        public DateTime LastUpdate { get; set; }
    }

    public enum OrderSide
    {
        Buy = 1,
        Sell = -1
    }

    public enum OrderType
    {
        Market,
        Limit,
        StopLoss,
        TakeProfit
    }

    public enum SignalType
    {
        Entry,
        Exit,
        Adjustment,
        Emergency
    }

    public enum StrategyType
    {
        StatisticalArbitrage,
        TriangularArbitrage,
        MeanReversion,
        Momentum,
        MarketMaking
    }
}
