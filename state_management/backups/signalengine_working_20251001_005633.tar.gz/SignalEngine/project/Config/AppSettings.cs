using System.ComponentModel.DataAnnotations;

namespace TradeServer.Config
{
    public class AppSettings
    {
        public RiskSettings Risk { get; set; } = new();
        public SignalSettings Signal { get; set; } = new();
        public StrategySettings Strategy { get; set; } = new();
        public PerformanceSettings Performance { get; set; } = new();
        public ExchangeSettings Exchange { get; set; } = new();
        public LoggingSettings Logging { get; set; } = new();
        public RedisSettings Redis { get; set; } = new();
    }

    public class RiskSettings
    {
        [Required]
        public bool KillSwitch { get; set; } = false;
        
        [Range(1, 1_000_000)]
        public decimal MaxNotionalPerOrder { get; set; } = 50_000m;
        
        [Range(1, 1000)]
        public int MaxOrdersPerMinutePerSymbol { get; set; } = 60;
        
        [Range(10, 5000)]
        public int SignalTtlMs { get; set; } = 150;
        
        [Range(1, 1000)]
        public int MaxSlippageBps { get; set; } = 25;
        
        [Range(0.01, 1.0)]
        public decimal MaxPositionSizePercent { get; set; } = 0.1m;
        
        [Range(1, 100_000_000)]
        public decimal MaxDailyNotionalPerSymbol { get; set; } = 1_000_000m;
        
        [Range(1, 10)]
        public int CircuitBreakerFailureThreshold { get; set; } = 5;
        
        [Range(1, 60)]
        public int CircuitBreakerResetMinutes { get; set; } = 5;
    }

    public class SignalSettings
    {
        [Range(10, 10000)]
        public int MaxAgeMs { get; set; } = 500;
        
        [Range(0.01, 1.0)]
        public decimal MinConfidence { get; set; } = 0.3m;
        
        [Range(1, 1000)]
        public int MaxSignalsPerSecond { get; set; } = 100;
        
        [Range(10, 1000)]
        public int QualityWindowSize { get; set; } = 50;
        
        [Range(0.1, 10.0)]
        public double MinSignalStrength { get; set; } = 1.0;
        
        public bool EnableDuplicateDetection { get; set; } = true;
        public bool EnableQualityFiltering { get; set; } = true;
        public bool EnableLatencyTracking { get; set; } = true;
    }

    public class StrategySettings
    {
        [Range(0.001, 1.0)]
        public double MinExpectedReturn { get; set; } = 0.01;
        
        [Range(0.1, 10.0)]
        public double ZScoreThreshold { get; set; } = 2.0;
        
        [Range(0.0, 1.0)]
        public double MaxRiskScore { get; set; } = 0.7;
        
        [Range(1, 100)]
        public int MaxConcurrentTrades { get; set; } = 10;
        
        [Range(10, 3600)]
        public int OpportunityTtlSeconds { get; set; } = 30;
        
        [Range(50, 10000)]
        public int MaxPriceHistory { get; set; } = 200;
        
        [Range(0.001, 1.0)]
        public double BaseExpectedReturn { get; set; } = 0.02;
        
        public bool EnableStatisticalArbitrage { get; set; } = true;
        public bool EnableTriangularArbitrage { get; set; } = true;
        public bool EnableMeanReversion { get; set; } = true;
        
        [Range(0.1, 10.0)]
        public double TriangularArbitrageThreshold { get; set; } = 0.001; // 0.1%
        
        [Range(10, 1000)]
        public int MinHistoryForStrategy { get; set; } = 50;
    }

    public class PerformanceSettings
    {
        [Range(1, 100)]
        public int MaxConcurrentProcessing { get; set; } = 10;
        
        [Range(100, 100000)]
        public int MessageBufferSize { get; set; } = 1000;
        
        [Range(1, 1000)]
        public int BatchProcessingSize { get; set; } = 50;
        
        [Range(1, 10000)]
        public int ProcessingTimeoutMs { get; set; } = 100;
        
        public bool EnableBatchProcessing { get; set; } = true;
        public bool EnableParallelProcessing { get; set; } = true;
        public bool EnableMemoryOptimization { get; set; } = true;
        public bool EnableCpuOptimization { get; set; } = true;
        
        [Range(1, 3600)]
        public int MetricsCollectionIntervalSeconds { get; set; } = 10;
        
        [Range(1, 24)]
        public int MetricsRetentionHours { get; set; } = 4;
    }

    public class ExchangeSettings
    {
        public Dictionary<string, ExchangeConfig> Exchanges { get; set; } = new();
        
        [Range(100, 30000)]
        public int ConnectionTimeoutMs { get; set; } = 5000;
        
        [Range(1, 10)]
        public int MaxRetryAttempts { get; set; } = 3;
        
        [Range(100, 10000)]
        public int RetryDelayMs { get; set; } = 1000;
        
        public bool EnableHealthChecking { get; set; } = true;
        
        [Range(1, 300)]
        public int HealthCheckIntervalSeconds { get; set; } = 30;
    }

    public class ExchangeConfig
    {
        [Required]
        public string Name { get; set; } = string.Empty;
        
        [Required]
        public string ApiUrl { get; set; } = string.Empty;
        
        [Required]
        public string WebSocketUrl { get; set; } = string.Empty;
        
        public string ApiKey { get; set; } = string.Empty;
        public string SecretKey { get; set; } = string.Empty;
        public string Passphrase { get; set; } = string.Empty;
        
        public bool Enabled { get; set; } = true;
        public bool TestMode { get; set; } = false;
        
        [Range(1, 1000)]
        public int RateLimitPerSecond { get; set; } = 10;
        
        public List<string> SupportedSymbols { get; set; } = new();
        public Dictionary<string, object> CustomSettings { get; set; } = new();
    }

    public class LoggingSettings
    {
        public string LogLevel { get; set; } = "Information";
        public bool EnableConsoleLogging { get; set; } = true;
        public bool EnableFileLogging { get; set; } = true;
        public bool EnableStructuredLogging { get; set; } = true;
        
        public string LogFilePath { get; set; } = "logs/tradeserver.log";
        
        [Range(1, 1000)]
        public int MaxLogFileSizeMB { get; set; } = 100;
        
        [Range(1, 365)]
        public int LogRetentionDays { get; set; } = 30;
        
        public bool EnablePerformanceLogging { get; set; } = true;
        public bool EnableTradeLogging { get; set; } = true;
        public bool EnableRiskLogging { get; set; } = true;
        
        public List<string> SensitiveFields { get; set; } = new() { "ApiKey", "SecretKey", "Passphrase" };
    }

    public class RedisSettings
    {
        [Required]
        public string ConnectionString { get; set; } = "localhost:6379";
        
        public string Password { get; set; } = string.Empty;
        
        [Range(0, 15)]
        public int Database { get; set; } = 0;
        
        [Range(1000, 30000)]
        public int ConnectTimeoutMs { get; set; } = 5000;
        
        [Range(1000, 30000)]
        public int SyncTimeoutMs { get; set; } = 5000;
        
        public bool EnableCompression { get; set; } = true;
        public bool EnableRetry { get; set; } = true;
        
        [Range(1, 10)]
        public int MaxRetryAttempts { get; set; } = 3;
        
        public string KeyPrefix { get; set; } = "tradeserver:";
        
        [Range(60, 86400)]
        public int DefaultExpirySeconds { get; set; } = 3600;
        
        public Dictionary<string, int> CustomExpiries { get; set; } = new();
    }
}
