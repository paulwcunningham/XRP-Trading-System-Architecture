using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;
using TradeServer.Models;
using TradeServer.Config;

namespace TradeServer.Validation
{
    public class SignalQualityValidator
    {
        private readonly ILogger _logger;
        private readonly AppSettings _config;
        private readonly ConcurrentDictionary<string, SignalMetrics> _symbolMetrics = new();
        private readonly ConcurrentDictionary<string, Queue<SignalQuality>> _recentSignals = new();
        private readonly object _lockObject = new();

        public SignalQualityValidator(ILogger<SignalQualityValidator> logger, AppSettings config)
        {
            _logger = logger;
            _config = config;
        }

        public SignalValidationResult ValidateSignal(TradingSignal signal)
        {
            try
            {
                var metrics = _symbolMetrics.GetOrAdd(signal.Symbol, _ => new SignalMetrics());
                var recentSignals = _recentSignals.GetOrAdd(signal.Symbol, _ => new Queue<SignalQuality>());

                // Check signal freshness
                var signalAge = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - signal.TimestampMs;
                if (signalAge > _config.Signal.MaxAgeMs)
                {
                    return SignalValidationResult.Reject("signal_too_old", 
                        $"Signal age {signalAge}ms exceeds maximum {_config.Signal.MaxAgeMs}ms");
                }

                // Check signal strength
                if (Math.Abs(signal.Confidence) < _config.Signal.MinConfidence)
                {
                    return SignalValidationResult.Reject("confidence_too_low", 
                        $"Signal confidence {signal.Confidence:F4} below minimum {_config.Signal.MinConfidence:F4}");
                }

                // Check for duplicate signals
                if (IsDuplicateSignal(signal, recentSignals))
                {
                    return SignalValidationResult.Reject("duplicate_signal", 
                        "Similar signal already processed recently");
                }

                // Validate signal consistency
                var consistencyResult = ValidateSignalConsistency(signal, metrics);
                if (!consistencyResult.IsValid)
                    return consistencyResult;

                // Update metrics and tracking
                UpdateSignalMetrics(signal, metrics, recentSignals);

                return SignalValidationResult.Approve($"Signal validated: confidence={signal.Confidence:F4}, age={signalAge}ms");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[SignalValidator] Error validating signal for {Symbol}", signal.Symbol);
                return SignalValidationResult.Reject("validation_error", $"Signal validation failed: {ex.Message}");
            }
        }

        private bool IsDuplicateSignal(TradingSignal signal, Queue<SignalQuality> recentSignals)
        {
            lock (_lockObject)
            {
                var cutoffTime = DateTimeOffset.UtcNow.AddSeconds(-30).ToUnixTimeMilliseconds();
                
                // Remove old signals
                while (recentSignals.Count > 0 && recentSignals.Peek().TimestampMs < cutoffTime)
                {
                    recentSignals.Dequeue();
                }

                // Check for similar recent signals
                foreach (var recent in recentSignals)
                {
                    if (Math.Abs(recent.Price - signal.Price) / signal.Price < 0.001m && // Within 0.1% price
                        Math.Sign(recent.Direction) == Math.Sign(signal.Direction)) // Same direction
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        private SignalValidationResult ValidateSignalConsistency(TradingSignal signal, SignalMetrics metrics)
        {
            // Check price reasonableness
            if (signal.Price <= 0)
            {
                return SignalValidationResult.Reject("invalid_price", "Signal price must be positive");
            }

            // Check against recent price history
            if (metrics.RecentPrices.Count > 0)
            {
                var avgRecentPrice = metrics.RecentPrices.Average();
                var priceDeviation = Math.Abs(signal.Price - avgRecentPrice) / avgRecentPrice;
                
                if (priceDeviation > 0.05m) // 5% deviation threshold
                {
                    return SignalValidationResult.Reject("price_deviation_high", 
                        $"Price deviation {priceDeviation:P2} exceeds 5% threshold");
                }
            }

            // Check signal direction consistency
            if (metrics.RecentDirections.Count >= 3)
            {
                var recentDirectionChanges = 0;
                for (int i = 1; i < metrics.RecentDirections.Count; i++)
                {
                    if (Math.Sign(metrics.RecentDirections[i]) != Math.Sign(metrics.RecentDirections[i-1]))
                        recentDirectionChanges++;
                }

                if (recentDirectionChanges >= 3) // Too many direction changes
                {
                    return SignalValidationResult.Reject("direction_instability", 
                        "Too many recent direction changes detected");
                }
            }

            return SignalValidationResult.Approve("Signal consistency validated");
        }

        private void UpdateSignalMetrics(TradingSignal signal, SignalMetrics metrics, Queue<SignalQuality> recentSignals)
        {
            lock (_lockObject)
            {
                // Update price history
                metrics.RecentPrices.Add(signal.Price);
                if (metrics.RecentPrices.Count > 20)
                    metrics.RecentPrices.RemoveAt(0);

                // Update direction history
                metrics.RecentDirections.Add(signal.Direction);
                if (metrics.RecentDirections.Count > 10)
                    metrics.RecentDirections.RemoveAt(0);

                // Add to recent signals
                recentSignals.Enqueue(new SignalQuality
                {
                    TimestampMs = signal.TimestampMs,
                    Price = signal.Price,
                    Direction = signal.Direction,
                    Confidence = signal.Confidence
                });

                // Keep only recent signals
                while (recentSignals.Count > 50)
                    recentSignals.Dequeue();

                // Update counters
                metrics.TotalSignals++;
                metrics.LastSignalTime = DateTimeOffset.UtcNow;
            }
        }

        public SignalQualityReport GetQualityReport(string symbol)
        {
            if (!_symbolMetrics.TryGetValue(symbol, out var metrics))
                return new SignalQualityReport { Symbol = symbol, Message = "No signals processed" };

            var recentSignals = _recentSignals.GetOrAdd(symbol, _ => new Queue<SignalQuality>());
            
            lock (_lockObject)
            {
                var avgConfidence = recentSignals.Count > 0 ? recentSignals.Average(s => Math.Abs(s.Confidence)) : 0;
                var signalRate = metrics.TotalSignals / Math.Max(1, (DateTimeOffset.UtcNow - metrics.FirstSignalTime).TotalMinutes);

                return new SignalQualityReport
                {
                    Symbol = symbol,
                    TotalSignals = metrics.TotalSignals,
                    AverageConfidence = avgConfidence,
                    SignalRatePerMinute = signalRate,
                    LastSignalAge = (DateTimeOffset.UtcNow - metrics.LastSignalTime).TotalSeconds,
                    PriceStability = CalculatePriceStability(metrics.RecentPrices),
                    DirectionConsistency = CalculateDirectionConsistency(metrics.RecentDirections)
                };
            }
        }

        private double CalculatePriceStability(List<decimal> prices)
        {
            if (prices.Count < 2) return 1.0;
            
            var mean = prices.Average();
            var variance = prices.Sum(p => Math.Pow((double)(p - mean), 2)) / prices.Count;
            var stdDev = Math.Sqrt(variance);
            
            return Math.Max(0, 1.0 - (stdDev / (double)mean));
        }

        private double CalculateDirectionConsistency(List<decimal> directions)
        {
            if (directions.Count < 2) return 1.0;
            
            var changes = 0;
            for (int i = 1; i < directions.Count; i++)
            {
                if (Math.Sign(directions[i]) != Math.Sign(directions[i-1]))
                    changes++;
            }
            
            return 1.0 - ((double)changes / (directions.Count - 1));
        }
    }

    public class SignalMetrics
    {
        public List<decimal> RecentPrices { get; } = new();
        public List<decimal> RecentDirections { get; } = new();
        public long TotalSignals { get; set; }
        public DateTimeOffset FirstSignalTime { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset LastSignalTime { get; set; } = DateTimeOffset.UtcNow;
    }

    public class SignalQuality
    {
        public long TimestampMs { get; set; }
        public decimal Price { get; set; }
        public decimal Direction { get; set; }
        public decimal Confidence { get; set; }
    }

    public class SignalQualityReport
    {
        public string Symbol { get; set; } = string.Empty;
        public long TotalSignals { get; set; }
        public decimal AverageConfidence { get; set; }
        public double SignalRatePerMinute { get; set; }
        public double LastSignalAge { get; set; }
        public double PriceStability { get; set; }
        public double DirectionConsistency { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}
