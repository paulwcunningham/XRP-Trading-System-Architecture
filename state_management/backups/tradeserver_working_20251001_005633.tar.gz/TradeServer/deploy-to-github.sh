#!/bin/bash

# TradeServer GitHub Deployment Script
# This script pushes the corrected TradeServer build to GitHub and triggers deployment

set -e

echo "=== TradeServer GitHub Deployment ==="
echo "Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"

# Check if we're in a git repository
if [ ! -d ".git" ]; then
    echo "ERROR: Not in a git repository. Please run this script from the TradeServer root directory."
    exit 1
fi

# Check if GitHub CLI is authenticated
if ! gh auth status >/dev/null 2>&1; then
    echo "GitHub CLI not authenticated. Please run: gh auth login"
    echo "Or set GH_TOKEN environment variable with your GitHub token"
    exit 1
fi

# Get repository information
REPO_NAME="TradeServer-Corrected"
REPO_DESCRIPTION="Low-latency trading system with corrected build process and nanosecond precision"

echo "Creating GitHub repository: $REPO_NAME"

# Create repository if it doesn't exist
if ! gh repo view "$REPO_NAME" >/dev/null 2>&1; then
    echo "Creating new repository..."
    gh repo create "$REPO_NAME" --public --description "$REPO_DESCRIPTION"
else
    echo "Repository already exists"
fi

# Add remote if not already added
if ! git remote get-url origin >/dev/null 2>&1; then
    echo "Adding GitHub remote..."
    gh repo set-default "$REPO_NAME"
    git remote add origin "https://github.com/$(gh api user --jq .login)/$REPO_NAME.git"
else
    echo "Remote origin already configured"
fi

# Ensure we're on main branch
git checkout main 2>/dev/null || git checkout -b main

# Add any new files
echo "Adding any new files..."
git add .

# Check if there are changes to commit
if git diff --staged --quiet; then
    echo "No changes to commit"
else
    echo "Committing changes..."
    git commit -m "Update: Corrected build process and deployment artifacts

- Fixed GitHub Actions workflow directory creation issue
- Maintained nanosecond precision for low-latency trading
- Resolved dependency injection issues
- Complete deployment package ready
- Build timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
fi

# Push to GitHub
echo "Pushing to GitHub..."
git push -u origin main

# Create a release with the deployment artifacts
echo "Creating GitHub release..."
RELEASE_TAG="v1.0.$(date +%Y%m%d-%H%M%S)"
RELEASE_TITLE="TradeServer Corrected Build - $(date +%Y-%m-%d)"
RELEASE_NOTES="## TradeServer Corrected Build

### 🚀 **Build Process Corrections Applied**
- Fixed GitHub Actions workflow with proper directory creation
- Resolved dependency injection issues
- Maintained nanosecond precision for low-latency trading

### 📦 **Complete Trading System**
- **7-Layer Risk Management**: Kill switches, circuit breakers, position limits
- **Signal Processing**: Real-time quality validation and filtering
- **Statistical Arbitrage**: Z-score analysis and mean reversion strategies
- **Performance Optimization**: Nanosecond latency tracking and memory pooling
- **Health Monitoring**: Comprehensive metrics and status checks

### 🛠 **Deployment Ready**
- Native .NET 8 compilation for optimal performance
- Complete deployment scripts (start.sh, stop.sh, status.sh)
- Production and development configurations
- Comprehensive documentation and CI/CD pipeline

### 📋 **Artifacts Included**
- \`tradeserver-deployment-final.tar.gz\` - Complete deployment package
- Source code with all corrections applied
- GitHub Actions workflow with logging fixes
- Deployment documentation and scripts

### ⚡ **Performance Features**
- Nanosecond precision timing throughout
- Multi-layer risk validation
- Real-time signal processing
- Low-latency order execution
- Comprehensive monitoring and alerting

Built on: $(date -u +%Y-%m-%dT%H:%M:%SZ)
Commit: $(git rev-parse HEAD)"

# Create the release
gh release create "$RELEASE_TAG" \
    --title "$RELEASE_TITLE" \
    --notes "$RELEASE_NOTES" \
    tradeserver-deployment-final.tar.gz

echo "✅ Successfully deployed to GitHub!"
echo "Repository: https://github.com/$(gh api user --jq .login)/$REPO_NAME"
echo "Release: $RELEASE_TAG"
echo ""
echo "🚀 GitHub Actions will now automatically:"
echo "   1. Build the corrected application"
echo "   2. Run tests and validation"
echo "   3. Create deployment package"
echo "   4. Deploy to configured servers"
echo "   5. Capture and commit runtime logs"
echo ""
echo "Monitor the deployment at:"
echo "https://github.com/$(gh api user --jq .login)/$REPO_NAME/actions"
