#!/bin/bash

# Configure GitHub Repository Secrets and Variables for TradeServer Deployment
# This script sets up all the necessary secrets and variables for automated deployment

set -e

# Repository list
REPOS=(
    "paulwcunningham/SignalEngine"
    "paulwcunningham/Monitoring-Server"
    "paulwcunningham/FeedServer"
    "paulwcunningham/TradeServer"
)

echo "=== CONFIGURING GITHUB SECRETS AND VARIABLES ==="
echo "Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo ""

# Check if GitHub CLI is authenticated
if ! gh auth status >/dev/null 2>&1; then
    echo "❌ GitHub CLI not authenticated. Please run: gh auth login"
    exit 1
fi

echo "✅ GitHub CLI authenticated"

# Function to set secrets and variables for a repository
configure_repo() {
    local repo="$1"
    echo ""
    echo "--- Configuring $repo ---"
    
    # Set repository variables (public configuration)
    echo "Setting repository variables..."
    
    # Deployment configuration
    gh variable set DEPLOY_ENABLED --body "true" --repo "$repo"
    gh variable set BASTION_HOST --body "57.181.26.87" --repo "$repo"
    
    # Tokyo production server IPs
    gh variable set TRADE_SERVER_IP --body "10.0.153
