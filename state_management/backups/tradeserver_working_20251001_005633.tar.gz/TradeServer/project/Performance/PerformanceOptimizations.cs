using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using Microsoft.Extensions.Logging;
using TradeServer.Config;
using TradeServer.Models;

namespace TradeServer.Performance
{
    public class PerformanceOptimizations
    {
        private readonly ILogger _logger;
        private readonly AppSettings _config;
        private readonly ConcurrentQueue<double> _latencyMeasurements = new();
        private readonly ConcurrentQueue<PerformanceSnapshot> _performanceHistory = new();
        private readonly object _lockObject = new();
        
        // Performance counters
        private long _totalOperations = 0;
        private long _totalLatencyMicroseconds = 0;
        private readonly Stopwatch _uptimeStopwatch = Stopwatch.StartNew();
        
        // Memory optimization
        private readonly ObjectPool<StringBuilder> _stringBuilderPool;
        private readonly ObjectPool<List<decimal>> _listPool;
        
        // CPU optimization
        private readonly SemaphoreSlim _processingLimiter;
        private readonly CancellationTokenSource _cancellationTokenSource = new();

        public PerformanceOptimizations(ILogger<PerformanceOptimizations> logger, AppSettings config)
        {
            _logger = logger;
            _config = config;
            
            // Initialize object pools for memory optimization
            _stringBuilderPool = new ObjectPool<StringBuilder>(() => new StringBuilder(256));
            _listPool = new ObjectPool<List<decimal>>(() => new List<decimal>(100));
            
            // Initialize processing limiter for CPU optimization
            _processingLimiter = new SemaphoreSlim(_config.Performance.MaxConcurrentProcessing);
            
            // Start background performance monitoring
            _ = Task.Run(MonitorPerformanceAsync);
        }

        public void RecordSignalProcessingTime(double nanoseconds)
        {
            Interlocked.Increment(ref _totalOperations);
            Interlocked.Add(ref _totalLatencyMicroseconds, (long)(nanoseconds / 1000)); // Convert to microseconds for storage
            
            _latencyMeasurements.Enqueue(nanoseconds);
            
            // Keep only recent measurements
            while (_latencyMeasurements.Count > 1000)
            {
                _latencyMeasurements.TryDequeue(out _);
            }
        }

        public PerformanceMetrics GetCurrentMetrics()
        {
            var totalOps = Interlocked.Read(ref _totalOperations);
            var totalLatency = Interlocked.Read(ref _totalLatencyMicroseconds);
            
            var avgLatency = totalOps > 0 ? (double)totalLatency / totalOps : 0;
            var throughput = totalOps / Math.Max(1, _uptimeStopwatch.Elapsed.TotalSeconds);
            
            // Get system metrics
            var process = Process.GetCurrentProcess();
            var cpuUsage = GetCpuUsage();
            var memoryUsage = process.WorkingSet64 / (1024.0 * 1024.0); // MB
            
            return new PerformanceMetrics
            {
                LatencyMicroseconds = avgLatency,
                ThroughputPerSecond = throughput,
                CpuUsagePercent = cpuUsage,
                MemoryUsageMB = memoryUsage,
                MessagesProcessed = totalOps,
                ErrorCount = 0, // Would be tracked separately
                LastUpdate = DateTime.UtcNow
            };
        }

        public async Task<T> ExecuteWithPerformanceTracking<T>(Func<Task<T>> operation, string operationName)
        {
            if (!_config.Performance.EnableCpuOptimization)
            {
                return await operation();
            }
            
            await _processingLimiter.WaitAsync(_cancellationTokenSource.Token);
            
            try
            {
                var stopwatch = Stopwatch.StartNew();
                var result = await operation();
                stopwatch.Stop();
                
                RecordSignalProcessingTime(stopwatch.Elapsed.Ticks * 100); // Convert to nanoseconds
                
                if (stopwatch.ElapsedMilliseconds > _config.Performance.ProcessingTimeoutMs)
                {
                    _logger.LogWarning("[Performance] Operation {OperationName} took {ElapsedMs}ms, exceeding timeout {TimeoutMs}ms", 
                        operationName, stopwatch.ElapsedMilliseconds, _config.Performance.ProcessingTimeoutMs);
                }
                
                return result;
            }
            finally
            {
                _processingLimiter.Release();
            }
        }

        public async Task<List<T>> ProcessBatchAsync<T, TResult>(
            IEnumerable<T> items, 
            Func<T, Task<TResult>> processor,
            string operationName)
        {
            if (!_config.Performance.EnableBatchProcessing)
            {
                var results = new List<T>();
                foreach (var item in items)
                {
                    await processor(item);
                    results.Add(item);
                }
                return results;
            }
            
            var batches = items.Chunk(_config.Performance.BatchProcessingSize);
            var allResults = new ConcurrentBag<T>();
            
            var tasks = batches.Select(async batch =>
            {
                await _processingLimiter.WaitAsync(_cancellationTokenSource.Token);
                try
                {
                    var batchTasks = batch.Select(async item =>
                    {
                        await processor(item);
                        return item;
                    });
                    
                    var batchResults = await Task.WhenAll(batchTasks);
                    foreach (var result in batchResults)
                    {
                        allResults.Add(result);
                    }
                }
                finally
                {
                    _processingLimiter.Release();
                }
            });
            
            await Task.WhenAll(tasks);
            return allResults.ToList();
        }

        public StringBuilder GetStringBuilder()
        {
            if (!_config.Performance.EnableMemoryOptimization)
                return new StringBuilder();
                
            return _stringBuilderPool.Get();
        }

        public void ReturnStringBuilder(StringBuilder sb)
        {
            if (!_config.Performance.EnableMemoryOptimization)
                return;
                
            sb.Clear();
            _stringBuilderPool.Return(sb);
        }

        public List<decimal> GetDecimalList()
        {
            if (!_config.Performance.EnableMemoryOptimization)
                return new List<decimal>();
                
            return _listPool.Get();
        }

        public void ReturnDecimalList(List<decimal> list)
        {
            if (!_config.Performance.EnableMemoryOptimization)
                return;
                
            list.Clear();
            _listPool.Return(list);
        }

        private double GetCpuUsage()
        {
            try
            {
                var process = Process.GetCurrentProcess();
                var startTime = DateTime.UtcNow;
                var startCpuUsage = process.TotalProcessorTime;
                
                Thread.Sleep(100); // Small delay for measurement
                
                var endTime = DateTime.UtcNow;
                var endCpuUsage = process.TotalProcessorTime;
                
                var cpuUsedMs = (endCpuUsage - startCpuUsage).TotalMilliseconds;
                var totalMsPassed = (endTime - startTime).TotalMilliseconds;
                var cpuUsageTotal = cpuUsedMs / (Environment.ProcessorCount * totalMsPassed);
                
                return Math.Min(100.0, Math.Max(0.0, cpuUsageTotal * 100));
            }
            catch
            {
                return 0.0; // Return 0 if unable to measure
            }
        }

        private async Task MonitorPerformanceAsync()
        {
            while (!_cancellationTokenSource.Token.IsCancellationRequested)
            {
                try
                {
                    var metrics = GetCurrentMetrics();
                    var snapshot = new PerformanceSnapshot
                    {
                        Timestamp = DateTime.UtcNow,
                        Metrics = metrics
                    };
                    
                    _performanceHistory.Enqueue(snapshot);
                    
                    // Keep only recent history
                    var cutoffTime = DateTime.UtcNow.AddHours(-_config.Performance.MetricsRetentionHours);
                    while (_performanceHistory.TryPeek(out var oldest) && oldest.Timestamp < cutoffTime)
                    {
                        _performanceHistory.TryDequeue(out _);
                    }
                    
                    // Log performance warnings
                    if (metrics.LatencyMicroseconds > 1000) // > 1ms
                    {
                        _logger.LogWarning("[Performance] High latency detected: {LatencyMs:F2}ms", 
                            metrics.LatencyMicroseconds / 1000);
                    }
                    
                    if (metrics.CpuUsagePercent > 80)
                    {
                        _logger.LogWarning("[Performance] High CPU usage: {CpuUsage:F1}%", metrics.CpuUsagePercent);
                    }
                    
                    if (metrics.MemoryUsageMB > 1000) // > 1GB
                    {
                        _logger.LogWarning("[Performance] High memory usage: {MemoryMB:F1}MB", metrics.MemoryUsageMB);
                    }
                    
                    await Task.Delay(TimeSpan.FromSeconds(_config.Performance.MetricsCollectionIntervalSeconds), 
                        _cancellationTokenSource.Token);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "[Performance] Error in performance monitoring");
                    await Task.Delay(5000, _cancellationTokenSource.Token); // Wait before retry
                }
            }
        }

        public PerformanceReport GenerateReport()
        {
            var snapshots = _performanceHistory.ToArray();
            if (snapshots.Length == 0)
            {
                return new PerformanceReport
                {
                    GeneratedAt = DateTime.UtcNow,
                    Message = "No performance data available"
                };
            }
            
            var latencies = snapshots.Select(s => s.Metrics.LatencyMicroseconds).ToArray();
            var throughputs = snapshots.Select(s => s.Metrics.ThroughputPerSecond).ToArray();
            var cpuUsages = snapshots.Select(s => s.Metrics.CpuUsagePercent).ToArray();
            var memoryUsages = snapshots.Select(s => s.Metrics.MemoryUsageMB).ToArray();
            
            return new PerformanceReport
            {
                GeneratedAt = DateTime.UtcNow,
                SampleCount = snapshots.Length,
                TimeRange = new TimeSpan(snapshots.Last().Timestamp.Ticks - snapshots.First().Timestamp.Ticks),
                
                AverageLatencyMicroseconds = latencies.Average(),
                P95LatencyMicroseconds = CalculatePercentile(latencies, 0.95),
                P99LatencyMicroseconds = CalculatePercentile(latencies, 0.99),
                
                AverageThroughput = throughputs.Average(),
                PeakThroughput = throughputs.Max(),
                
                AverageCpuUsage = cpuUsages.Average(),
                PeakCpuUsage = cpuUsages.Max(),
                
                AverageMemoryUsage = memoryUsages.Average(),
                PeakMemoryUsage = memoryUsages.Max(),
                
                TotalOperations = Interlocked.Read(ref _totalOperations),
                UptimeSeconds = _uptimeStopwatch.Elapsed.TotalSeconds
            };
        }

        private double CalculatePercentile(double[] values, double percentile)
        {
            if (values.Length == 0) return 0;
            
            var sorted = values.OrderBy(x => x).ToArray();
            var index = (int)Math.Ceiling(percentile * sorted.Length) - 1;
            return sorted[Math.Max(0, Math.Min(index, sorted.Length - 1))];
        }

        public void Dispose()
        {
            _cancellationTokenSource.Cancel();
            _processingLimiter?.Dispose();
            _cancellationTokenSource?.Dispose();
        }
    }

    public class ObjectPool<T> where T : class
    {
        private readonly ConcurrentQueue<T> _objects = new();
        private readonly Func<T> _objectGenerator;
        private readonly int _maxSize;

        public ObjectPool(Func<T> objectGenerator, int maxSize = 100)
        {
            _objectGenerator = objectGenerator;
            _maxSize = maxSize;
        }

        public T Get()
        {
            return _objects.TryDequeue(out var item) ? item : _objectGenerator();
        }

        public void Return(T item)
        {
            if (_objects.Count < _maxSize)
            {
                _objects.Enqueue(item);
            }
        }
    }

    public class PerformanceSnapshot
    {
        public DateTime Timestamp { get; set; }
        public PerformanceMetrics Metrics { get; set; } = new();
    }

    public class PerformanceReport
    {
        public DateTime GeneratedAt { get; set; }
        public int SampleCount { get; set; }
        public TimeSpan TimeRange { get; set; }
        
        public double AverageLatencyMicroseconds { get; set; }
        public double P95LatencyMicroseconds { get; set; }
        public double P99LatencyMicroseconds { get; set; }
        
        public double AverageThroughput { get; set; }
        public double PeakThroughput { get; set; }
        
        public double AverageCpuUsage { get; set; }
        public double PeakCpuUsage { get; set; }
        
        public double AverageMemoryUsage { get; set; }
        public double PeakMemoryUsage { get; set; }
        
        public long TotalOperations { get; set; }
        public double UptimeSeconds { get; set; }
        
        public string Message { get; set; } = string.Empty;
    }
}
