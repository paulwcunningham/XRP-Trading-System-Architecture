using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Threading.Channels;
using TradeServer.Config;
using TradeServer.Models;
using TradeServer.Risk;
using TradeServer.Validation;
using TradeServer.Strategies;
using TradeServer.Performance;

namespace TradeServer.TradeServer
{
    public class TradingEngineService : BackgroundService
    {
        private readonly ILogger<TradingEngineService> _logger;
        private readonly AppSettings _config;
        private readonly ProductionRiskEngine _riskEngine;
        private readonly SignalQualityValidator _signalValidator;
        private readonly StatisticalArbitrageStrategy _statArbStrategy;
        private readonly PerformanceOptimizations _performance;
        
        private readonly Channel<TradingSignal> _signalChannel;
        private readonly Channel<OrderCommand> _orderChannel;
        private readonly CancellationTokenSource _cancellationTokenSource = new();
        
        private volatile bool _isRunning = false;
        private readonly object _lockObject = new();
        
        // Performance metrics
        private long _signalsProcessed = 0;
        private long _ordersGenerated = 0;
        private long _errorsEncountered = 0;
        private DateTime _startTime = DateTime.UtcNow;

        public TradingEngineService(
            ILogger<TradingEngineService> logger,
            AppSettings config,
            ProductionRiskEngine riskEngine,
            SignalQualityValidator signalValidator,
            StatisticalArbitrageStrategy statArbStrategy,
            PerformanceOptimizations performance)
        {
            _logger = logger;
            _config = config;
            _riskEngine = riskEngine;
            _signalValidator = signalValidator;
            _statArbStrategy = statArbStrategy;
            _performance = performance;
            
            // Create channels for signal and order processing
            var channelOptions = new BoundedChannelOptions(_config.Performance.MessageBufferSize)
            {
                FullMode = BoundedChannelFullMode.Wait,
                SingleReader = false,
                SingleWriter = false
            };
            
            _signalChannel = Channel.CreateBounded<TradingSignal>(channelOptions);
            _orderChannel = Channel.CreateBounded<OrderCommand>(channelOptions);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("[TradingEngine] Starting trading engine service");
            
            try
            {
                _isRunning = true;
                _startTime = DateTime.UtcNow;
                
                // Start processing tasks
                var tasks = new List<Task>
                {
                    ProcessSignalsAsync(stoppingToken),
                    ProcessOrdersAsync(stoppingToken),
                    MonitorPerformanceAsync(stoppingToken),
                    SimulateMarketDataAsync(stoppingToken) // For demonstration
                };
                
                _logger.LogInformation("[TradingEngine] All processing tasks started");
                
                // Wait for any task to complete or cancellation
                await Task.WhenAny(tasks);
                
                _logger.LogInformation("[TradingEngine] Trading engine service stopping");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[TradingEngine] Fatal error in trading engine");
                throw;
            }
            finally
            {
                _isRunning = false;
                _cancellationTokenSource.Cancel();
            }
        }

        private async Task ProcessSignalsAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("[TradingEngine] Signal processing task started");
            
            await foreach (var signal in _signalChannel.Reader.ReadAllAsync(cancellationToken))
            {
                try
                {
                    var startTime = DateTime.UtcNow;
                    
                    // Validate signal quality
                    var validationResult = _signalValidator.ValidateSignal(signal);
                    if (!validationResult.IsValid)
                    {
                        _logger.LogDebug("[TradingEngine] Signal rejected: {Reason}", validationResult.Message);
                        continue;
                    }
                    
                    // Process signal through strategies
                    await ProcessSignalThroughStrategies(signal);
                    
                    Interlocked.Increment(ref _signalsProcessed);
                    
                    var processingTime = (DateTime.UtcNow - startTime).Ticks * 100; // Convert to nanoseconds
                    _performance.RecordSignalProcessingTime(processingTime);
                    
                    if (_signalsProcessed % 1000 == 0)
                    {
                        _logger.LogInformation("[TradingEngine] Processed {Count} signals", _signalsProcessed);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "[TradingEngine] Error processing signal for {Symbol}", signal.Symbol);
                    Interlocked.Increment(ref _errorsEncountered);
                }
            }
        }

        private async Task ProcessSignalThroughStrategies(TradingSignal signal)
        {
            // Create mock market data for strategy evaluation
            var marketData = new MarketData
            {
                Prices = new Dictionary<string, decimal> { { signal.Symbol, signal.Price } },
                TimestampMs = signal.TimestampMs,
                Source = "SignalEngine"
            };
            
            // Add some related symbols for arbitrage strategies
            var relatedSymbols = GetRelatedSymbols(signal.Symbol);
            foreach (var (symbol, price) in relatedSymbols)
            {
                marketData.Prices[symbol] = price;
            }
            
            // Evaluate statistical arbitrage opportunities
            if (_config.Strategy.EnableStatisticalArbitrage)
            {
                var strategyResult = _statArbStrategy.EvaluateOpportunity(marketData);
                if (strategyResult.Success)
                {
                    foreach (var opportunity in strategyResult.Opportunities)
                    {
                        await GenerateOrderFromOpportunity(opportunity, signal);
                    }
                }
            }
        }

        private Dictionary<string, decimal> GetRelatedSymbols(string baseSymbol)
        {
            // Mock related symbols for demonstration
            var related = new Dictionary<string, decimal>();
            
            if (baseSymbol.Contains("BTC"))
            {
                related["ETHUSDT"] = 2500m + (decimal)(Random.Shared.NextDouble() * 100 - 50);
                related["ADAUSDT"] = 0.5m + (decimal)(Random.Shared.NextDouble() * 0.1 - 0.05);
            }
            else if (baseSymbol.Contains("ETH"))
            {
                related["BTCUSDT"] = 45000m + (decimal)(Random.Shared.NextDouble() * 1000 - 500);
                related["LINKUSDT"] = 15m + (decimal)(Random.Shared.NextDouble() * 2 - 1);
            }
            
            return related;
        }

        private async Task GenerateOrderFromOpportunity(ArbitrageOpportunity opportunity, TradingSignal originalSignal)
        {
            try
            {
                var order = new OrderCommand
                {
                    ClientOrderId = Guid.NewGuid().ToString(),
                    Symbol = opportunity.Symbol1,
                    Price = opportunity.Price1,
                    Quantity = CalculateOrderQuantity(opportunity),
                    Side = opportunity.Direction > 0 ? OrderSide.Buy : OrderSide.Sell,
                    Type = OrderType.Limit,
                    TsNanosSent = DateTimeOffset.UtcNow.Ticks * 100, // Convert ticks to nanoseconds
                    Strategy = opportunity.Type,
                    Tags = new Dictionary<string, object>
                    {
                        ["OriginalSignal"] = originalSignal.Symbol,
                        ["ExpectedReturn"] = opportunity.ExpectedReturn,
                        ["RiskScore"] = opportunity.RiskScore,
                        ["ZScore"] = opportunity.ZScore
                    }
                };
                
                // Validate order through risk engine
                var riskResult = _riskEngine.ValidateOrder(order);
                if (!riskResult.IsValid)
                {
                    _logger.LogWarning("[TradingEngine] Order rejected by risk engine: {Reason}", riskResult.Message);
                    _riskEngine.RecordRejection(order.Symbol, riskResult.ReasonCode);
                    return;
                }
                
                // Send order for execution
                await _orderChannel.Writer.WriteAsync(order);
                Interlocked.Increment(ref _ordersGenerated);
                
                _logger.LogInformation("[TradingEngine] Generated order {OrderId} for {Symbol}: {Side} {Quantity} @ {Price}", 
                    order.ClientOrderId, order.Symbol, order.Side, order.Quantity, order.Price);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[TradingEngine] Error generating order from opportunity");
                Interlocked.Increment(ref _errorsEncountered);
            }
        }

        private decimal CalculateOrderQuantity(ArbitrageOpportunity opportunity)
        {
            // Simple position sizing based on expected return and risk
            var baseQuantity = 100m; // Base quantity
            var riskAdjustment = (decimal)(1.0 - opportunity.RiskScore);
            var returnAdjustment = (decimal)Math.Min(opportunity.ExpectedReturn * 10, 2.0);
            
            return Math.Max(1m, baseQuantity * riskAdjustment * returnAdjustment);
        }

        private async Task ProcessOrdersAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("[TradingEngine] Order processing task started");
            
            await foreach (var order in _orderChannel.Reader.ReadAllAsync(cancellationToken))
            {
                try
                {
                    // Simulate order execution
                    await SimulateOrderExecution(order);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "[TradingEngine] Error processing order {OrderId}", order.ClientOrderId);
                    Interlocked.Increment(ref _errorsEncountered);
                }
            }
        }

        private async Task SimulateOrderExecution(OrderCommand order)
        {
            // Simulate network latency
            await Task.Delay(Random.Shared.Next(5, 20));
            
            // Simulate execution
            var executed = Random.Shared.NextDouble() > 0.1; // 90% execution rate
            
            if (executed)
            {
                _logger.LogInformation("[TradingEngine] Order {OrderId} executed: {Side} {Quantity} {Symbol} @ {Price}", 
                    order.ClientOrderId, order.Side, order.Quantity, order.Symbol, order.Price);
            }
            else
            {
                _logger.LogWarning("[TradingEngine] Order {OrderId} failed to execute", order.ClientOrderId);
            }
        }

        private async Task MonitorPerformanceAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("[TradingEngine] Performance monitoring task started");
            
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    await Task.Delay(TimeSpan.FromSeconds(_config.Performance.MetricsCollectionIntervalSeconds), cancellationToken);
                    
                    var uptime = DateTime.UtcNow - _startTime;
                    var signalsPerSecond = _signalsProcessed / Math.Max(1, uptime.TotalSeconds);
                    var ordersPerSecond = _ordersGenerated / Math.Max(1, uptime.TotalSeconds);
                    
                    var metrics = _performance.GetCurrentMetrics();
                    
                    _logger.LogInformation("[TradingEngine] Performance: Signals={SignalsProcessed} ({SignalsPerSec:F1}/s), Orders={OrdersGenerated} ({OrdersPerSec:F1}/s), Errors={Errors}, Latency={LatencyUs:F1}μs", 
                        _signalsProcessed, signalsPerSecond, _ordersGenerated, ordersPerSecond, _errorsEncountered, metrics.LatencyMicroseconds);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "[TradingEngine] Error in performance monitoring");
                }
            }
        }

        private async Task SimulateMarketDataAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("[TradingEngine] Market data simulation started");
            
            var symbols = new[] { "BTCUSDT", "ETHUSDT", "ADAUSDT", "DOTUSDT" };
            var basePrices = new Dictionary<string, decimal>
            {
                ["BTCUSDT"] = 45000m,
                ["ETHUSDT"] = 2500m,
                ["ADAUSDT"] = 0.5m,
                ["DOTUSDT"] = 8m
            };
            
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    foreach (var symbol in symbols)
                    {
                        var basePrice = basePrices[symbol];
                        var priceChange = (decimal)(Random.Shared.NextDouble() * 0.02 - 0.01); // ±1% change
                        var newPrice = basePrice * (1 + priceChange);
                        basePrices[symbol] = newPrice;
                        
                        var signal = new TradingSignal
                        {
                            Symbol = symbol,
                            Price = newPrice,
                            Direction = priceChange > 0 ? 1 : -1,
                            Confidence = (decimal)Random.Shared.NextDouble(),
                            TimestampMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                            Source = "MarketDataSimulator"
                        };
                        
                        await _signalChannel.Writer.WriteAsync(signal, cancellationToken);
                    }
                    
                    await Task.Delay(100, cancellationToken); // 10 signals per second per symbol
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "[TradingEngine] Error in market data simulation");
                }
            }
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("[TradingEngine] Stopping trading engine service");
            
            _isRunning = false;
            
            // Complete the channels
            _signalChannel.Writer.Complete();
            _orderChannel.Writer.Complete();
            
            await base.StopAsync(cancellationToken);
            
            // Log final statistics
            var uptime = DateTime.UtcNow - _startTime;
            _logger.LogInformation("[TradingEngine] Final statistics: Uptime={Uptime}, Signals={Signals}, Orders={Orders}, Errors={Errors}", 
                uptime, _signalsProcessed, _ordersGenerated, _errorsEncountered);
        }

        public bool IsHealthy()
        {
            return _isRunning && !_cancellationTokenSource.Token.IsCancellationRequested;
        }
    }
}
