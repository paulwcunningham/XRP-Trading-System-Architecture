#!/bin/bash

# Deploy Corrected TradeServer Build to Tokyo Production Servers
# This script deploys to all production servers via bastion host

set -e

# Configuration
BASTION_HOST="ec2-user@57.181.26.87"
SSH_KEY="$HOME/.ssh/xrp-tokyo-key.pem"
DEPLOYMENT_PACKAGE="tradeserver-deployment-final.tar.gz"

# Production servers
declare -A SERVERS=(
    ["Tokyo-prd-feed"]="10.0.139.65"
    ["Tokyo-prd-Trade"]="10.0.153.50"
    ["Tokyo-prd-Monitor"]="10.0.133.93"
    ["Tokyo-jumphost"]="10.0.6.35"
)

# NATS cluster servers
declare -A NATS_SERVERS=(
    ["Tokyo-prd-NATS-A"]="10.0.139.242"
    ["Tokyo-prd-NATS-B"]="10.0.135.227"
    ["Tokyo-prd-NATS-C"]="10.0.130.100"
)

echo "=== DEPLOYING TO TOKYO PRODUCTION SERVERS ==="
echo "Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "Bastion Host: $BASTION_HOST"
echo "SSH Key: $SSH_KEY"
echo "Package: $DEPLOYMENT_PACKAGE"
echo ""

# Verify prerequisites
if [ ! -f "$SSH_KEY" ]; then
    echo "ERROR: SSH key not found at $SSH_KEY"
    exit 1
fi

if [ ! -f "$DEPLOYMENT_PACKAGE" ]; then
    echo "ERROR: Deployment package not found: $DEPLOYMENT_PACKAGE"
    exit 1
fi

# Test bastion host connectivity
echo "Testing bastion host connectivity..."
if ssh -i "$SSH_KEY" -o ConnectTimeout=10 -o StrictHostKeyChecking=no "$BASTION_HOST" "echo 'Bastion accessible'" 2>/dev/null; then
    echo "✅ Bastion host accessible"
else
    echo "❌ Bastion host not accessible"
    exit 1
fi

# Function to deploy to a server
deploy_to_server() {
    local server_name="$1"
    local server_ip="$2"
    local server_type="$3"
    
    echo ""
    echo "--- Deploying to $server_name ($server_ip) ---"
    
    # Upload deployment package
    echo "Uploading deployment package..."
    if scp -i "$SSH_KEY" -o ProxyJump="$BASTION_HOST" -o StrictHostKeyChecking=no \
        "$DEPLOYMENT_PACKAGE" "ec2-user@$server_ip:~/"; then
        echo "✅ Package uploaded successfully"
    else
        echo "❌ Failed to upload package"
        return 1
    fi
    
    # Deploy on server
    echo "Deploying on server..."
    ssh -i "$SSH_KEY" -o ProxyJump="$BASTION_HOST" -o StrictHostKeyChecking=no \
        "ec2-user@$server_ip" << 'EOF'
        
        echo "=== DEPLOYMENT ON $(hostname) ==="
        echo "Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        
        # Create deployment directory
        mkdir -p ~/tradeserver-deployment
        cd ~/tradeserver-deployment
        
        # Extract package
        echo "Extracting deployment package..."
        tar -xzf ~/tradeserver-deployment-final.tar.gz
        
        # Make scripts executable
        chmod +x deployment/scripts/*.sh
        
        # Stop existing services if running
        echo "Stopping existing services..."
        pkill -f SignalEngine || echo "No existing SignalEngine processes"
        
        # Install .NET 8 if not present
        if ! command -v dotnet >/dev/null 2>&1; then
            echo "Installing .NET 8..."
            wget https://packages.microsoft.com/config/ubuntu/22.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
            sudo dpkg -i packages-microsoft-prod.deb
            sudo apt-get update
            sudo apt-get install -y dotnet-runtime-8.0
        fi
        
        # Start the application
        echo "Starting TradeServer application..."
        cd deployment
        nohup ./scripts/start.sh > ~/tradeserver.log 2>&1 &
        
        # Wait a moment and check status
        sleep 3
        ./scripts/status.sh
        
        echo "✅ Deployment completed on $(hostname)"
        echo "Log file: ~/tradeserver.log"
        echo "Status check: ./deployment/scripts/status.sh"
        
EOF
    
    if [ $? -eq 0 ]; then
        echo "✅ Successfully deployed to $server_name"
    else
        echo "❌ Failed to deploy to $server_name"
        return 1
    fi
}

# Deploy to main production servers
echo ""
echo "=== DEPLOYING TO MAIN PRODUCTION SERVERS ==="

# Deploy to Trade Server (highest priority)
deploy_to_server "Tokyo-prd-Trade" "${SERVERS[Tokyo-prd-Trade]}" "trading"

# Deploy to Feed Server
deploy_to_server "Tokyo-prd-feed" "${SERVERS[Tokyo-prd-feed]}" "feed"

# Deploy to Monitor Server
deploy_to_server "Tokyo-prd-Monitor" "${SERVERS[Tokyo-prd-Monitor]}" "monitoring"

# Optional: Deploy to jump host for testing
echo ""
echo "=== OPTIONAL: DEPLOY TO JUMP HOST FOR TESTING ==="
read -p "Deploy to Tokyo-jumphost for testing? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    deploy_to_server "Tokyo-jumphost" "${SERVERS[Tokyo-jumphost]}" "testing"
fi

echo ""
echo "=== DEPLOYMENT SUMMARY ==="
echo "✅ Deployment completed to Tokyo production servers"
echo ""
echo "🖥️  DEPLOYED SERVERS:"
for server in "${!SERVERS[@]}"; do
    echo "  - $server: ${SERVERS[$server]}"
done

echo ""
echo "📊 VERIFICATION COMMANDS:"
echo "# Check Trade Server status:"
echo "ssh -i $SSH_KEY -o ProxyJump=$BASTION_HOST ec2-user@${SERVERS[Tokyo-prd-Trade]} './deployment/scripts/status.sh'"
echo ""
echo "# Check Feed Server status:"
echo "ssh -i $SSH_KEY -o ProxyJump=$BASTION_HOST ec2-user@${SERVERS[Tokyo-prd-feed]} './deployment/scripts/status.sh'"
echo ""
echo "# Check Monitor Server status:"
echo "ssh -i $SSH_KEY -o ProxyJump=$BASTION_HOST ec2-user@${SERVERS[Tokyo-prd-Monitor]} './deployment/scripts/status.sh'"

echo ""
echo "🔧 FIXES DEPLOYED:"
echo "  ✅ GitHub Actions directory creation fixed"
echo "  ✅ Dependency injection issues resolved"
echo "  ✅ Nanosecond precision maintained"
echo "  ✅ Complete risk management system"
echo "  ✅ Statistical arbitrage strategies"
echo "  ✅ Performance optimization enabled"

echo ""
echo "📈 MONITORING:"
echo "  - Health endpoint: http://[SERVER_IP]:8080/health"
echo "  - Application logs: ~/tradeserver.log"
echo "  - Performance metrics: Built-in monitoring"
echo "  - Risk management: 7-layer validation active"

echo ""
echo "🎯 NEXT STEPS:"
echo "  1. Verify all services are running"
echo "  2. Check application logs for any issues"
echo "  3. Test trading functionality"
echo "  4. Monitor performance metrics"
echo "  5. Validate risk management systems"

echo ""
echo "✅ PRODUCTION DEPLOYMENT COMPLETE!"
