using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;
using TradeServer.Config;
using TradeServer.Models;

namespace TradeServer.Risk
{
    public class ProductionRiskEngine
    {
        private readonly AppSettings _config;
        private readonly ILogger _logger;
        private readonly ConcurrentDictionary<string, SymbolRiskState> _symbolStates = new();
        private readonly ConcurrentDictionary<string, List<DateTime>> _orderHistory = new();
        private readonly object _lockObject = new();
        
        // Risk limits
        private volatile bool _globalKillSwitch = false;
        private decimal _maxNotionalPerOrder = 50_000m;
        private volatile int _maxOrdersPerMinutePerSymbol = 60;
        private volatile int _signalTtlMs = 150;
        private volatile int _maxSlippageBps = 25;
        
        // Circuit breakers
        private readonly ConcurrentDictionary<string, CircuitBreaker> _circuitBreakers = new();

        public ProductionRiskEngine(AppSettings config, ILogger<ProductionRiskEngine> logger)
        {
            _config = config;
            _logger = logger;
            
            // Initialize from config
            _globalKillSwitch = config.Risk.KillSwitch;
            _maxNotionalPerOrder = config.Risk.MaxNotionalPerOrder;
            _maxOrdersPerMinutePerSymbol = config.Risk.MaxOrdersPerMinutePerSymbol;
            _signalTtlMs = config.Risk.SignalTtlMs;
            _maxSlippageBps = config.Risk.MaxSlippageBps;
            
            _logger.LogInformation("[RiskEngine] Initialized with limits: MaxNotional={MaxNotional}, MaxOrders={MaxOrders}/min", 
                _maxNotionalPerOrder, _maxOrdersPerMinutePerSymbol);
        }

        public RiskValidationResult ValidateOrder(OrderCommand order)
        {
            try
            {
                // Layer 1: Global Kill Switch
                if (_globalKillSwitch)
                {
                    return RiskValidationResult.Reject("global_kill_switch_active", 
                        "Global kill switch is active - all trading halted");
                }

                // Layer 2: Signal Freshness
                var signalAge = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - order.TsNanosSent / 1_000_000;
                if (signalAge > _signalTtlMs)
                {
                    return RiskValidationResult.Reject("signal_too_old", 
                        $"Signal age {signalAge}ms exceeds TTL {_signalTtlMs}ms");
                }

                // Layer 3: Order Size Validation
                var notional = order.Price * order.Quantity;
                if (notional > _maxNotionalPerOrder)
                {
                    return RiskValidationResult.Reject("notional_too_large", 
                        $"Notional {notional:F2} exceeds limit {_maxNotionalPerOrder:F2}");
                }

                if (notional < 10m) // Minimum notional
                {
                    return RiskValidationResult.Reject("notional_too_small", 
                        $"Notional {notional:F2} below minimum 10.00");
                }

                // Layer 4: Rate Limiting
                var rateCheckResult = CheckRateLimit(order.Symbol);
                if (!rateCheckResult.IsValid)
                    return rateCheckResult;

                // Layer 5: Price Validation
                var priceCheckResult = ValidatePrice(order);
                if (!priceCheckResult.IsValid)
                    return priceCheckResult;

                // Layer 6: Circuit Breaker Check
                var circuitBreakerResult = CheckCircuitBreaker(order.Symbol);
                if (!circuitBreakerResult.IsValid)
                    return circuitBreakerResult;

                // Layer 7: Symbol-Specific Risk Limits
                var symbolRiskResult = ValidateSymbolRisk(order);
                if (!symbolRiskResult.IsValid)
                    return symbolRiskResult;

                // All checks passed - update tracking
                UpdateRiskTracking(order);

                return RiskValidationResult.Approve($"Passed all 7 risk layers, notional={notional:F2}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[RiskEngine] Error validating order {OrderId}", order.ClientOrderId);
                return RiskValidationResult.Reject("validation_error", $"Risk validation failed: {ex.Message}");
            }
        }

        private RiskValidationResult CheckRateLimit(string symbol)
        {
            var now = DateTime.UtcNow;
            var key = symbol;
            
            if (!_orderHistory.TryGetValue(key, out var history))
            {
                history = new List<DateTime>();
                _orderHistory[key] = history;
            }

            lock (_lockObject)
            {
                // Remove orders older than 1 minute
                var cutoff = now.AddMinutes(-1);
                history.RemoveAll(t => t < cutoff);

                // Check if we're at the limit
                if (history.Count >= _maxOrdersPerMinutePerSymbol)
                {
                    return RiskValidationResult.Reject("rate_limit_exceeded", 
                        $"Symbol {symbol} has {history.Count} orders in last minute, limit is {_maxOrdersPerMinutePerSymbol}");
                }

                // Add current order
                history.Add(now);
            }

            return RiskValidationResult.Approve($"Rate limit OK: {history.Count}/{_maxOrdersPerMinutePerSymbol}");
        }

        private RiskValidationResult ValidatePrice(OrderCommand order)
        {
            // Get or create symbol state
            var symbolState = _symbolStates.GetOrAdd(order.Symbol, _ => new SymbolRiskState());
            
            // Update last seen price
            symbolState.UpdatePrice(order.Price);

            // Check for reasonable price (basic sanity check)
            if (order.Price <= 0)
            {
                return RiskValidationResult.Reject("invalid_price", "Price must be positive");
            }

            // Check for extreme price movements (if we have reference price)
            if (symbolState.ReferencePrice > 0)
            {
                var priceChange = Math.Abs(order.Price - symbolState.ReferencePrice) / symbolState.ReferencePrice;
                var maxPriceChange = 0.10m; // 10% max price change
                
                if (priceChange > maxPriceChange)
                {
                    return RiskValidationResult.Reject("extreme_price_movement", 
                        $"Price change {priceChange:P2} exceeds limit {maxPriceChange:P2}");
                }
            }

            return RiskValidationResult.Approve($"Price validation passed: {order.Price:F4}");
        }

        private RiskValidationResult CheckCircuitBreaker(string symbol)
        {
            var circuitBreaker = _circuitBreakers.GetOrAdd(symbol, _ => new CircuitBreaker());
            
            if (circuitBreaker.IsOpen)
            {
                if (circuitBreaker.CanAttemptReset())
                {
                    circuitBreaker.Reset();
                    _logger.LogInformation("[RiskEngine] Circuit breaker reset for {Symbol}", symbol);
                }
                else
                {
                    return RiskValidationResult.Reject("circuit_breaker_open", 
                        $"Circuit breaker is open for {symbol}");
                }
            }

            return RiskValidationResult.Approve("Circuit breaker check passed");
        }

        private RiskValidationResult ValidateSymbolRisk(OrderCommand order)
        {
            var symbolState = _symbolStates.GetOrAdd(order.Symbol, _ => new SymbolRiskState());
            
            // Check daily notional limits
            var dailyNotional = symbolState.GetDailyNotional();
            var maxDailyNotional = 1_000_000m; // $1M daily limit per symbol
            
            if (dailyNotional + (order.Price * order.Quantity) > maxDailyNotional)
            {
                return RiskValidationResult.Reject("daily_notional_exceeded", 
                    $"Daily notional {dailyNotional:F2} + order {order.Price * order.Quantity:F2} exceeds limit {maxDailyNotional:F2}");
            }

            return RiskValidationResult.Approve($"Symbol risk validation passed for {order.Symbol}");
        }

        private void UpdateRiskTracking(OrderCommand order)
        {
            var symbolState = _symbolStates.GetOrAdd(order.Symbol, _ => new SymbolRiskState());
            symbolState.AddOrder(order.Price * order.Quantity);
        }

        public void UpdateKillSwitch(bool enabled)
        {
            _globalKillSwitch = enabled;
            _logger.LogWarning("[RiskEngine] Global kill switch {Status}", enabled ? "ENABLED" : "DISABLED");
        }

        public void RecordRejection(string symbol, string reason)
        {
            var circuitBreaker = _circuitBreakers.GetOrAdd(symbol, _ => new CircuitBreaker());
            circuitBreaker.RecordFailure();
            
            _logger.LogWarning("[RiskEngine] Order rejected for {Symbol}: {Reason}", symbol, reason);
        }
    }

    public class SymbolRiskState
    {
        private decimal _referencePrice;
        private readonly List<decimal> _dailyNotionals = new();
        private DateTime _lastResetDate = DateTime.UtcNow.Date;
        private readonly object _lock = new();

        public decimal ReferencePrice => _referencePrice;

        public void UpdatePrice(decimal price)
        {
            if (_referencePrice == 0)
                _referencePrice = price;
            else
                _referencePrice = (_referencePrice * 0.99m) + (price * 0.01m); // EMA
        }

        public void AddOrder(decimal notional)
        {
            lock (_lock)
            {
                ResetIfNewDay();
                _dailyNotionals.Add(notional);
            }
        }

        public decimal GetDailyNotional()
        {
            lock (_lock)
            {
                ResetIfNewDay();
                return _dailyNotionals.Sum();
            }
        }

        private void ResetIfNewDay()
        {
            var today = DateTime.UtcNow.Date;
            if (today > _lastResetDate)
            {
                _dailyNotionals.Clear();
                _lastResetDate = today;
            }
        }
    }

    public class CircuitBreaker
    {
        private int _failureCount = 0;
        private DateTime _lastFailureTime = DateTime.MinValue;
        private readonly int _failureThreshold = 5;
        private readonly TimeSpan _resetTimeout = TimeSpan.FromMinutes(5);

        public bool IsOpen => _failureCount >= _failureThreshold && 
                             DateTime.UtcNow - _lastFailureTime < _resetTimeout;

        public void RecordFailure()
        {
            _failureCount++;
            _lastFailureTime = DateTime.UtcNow;
        }

        public bool CanAttemptReset()
        {
            return DateTime.UtcNow - _lastFailureTime >= _resetTimeout;
        }

        public void Reset()
        {
            _failureCount = 0;
            _lastFailureTime = DateTime.MinValue;
        }
    }
}
