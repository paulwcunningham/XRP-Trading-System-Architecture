using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Logging;

namespace TradeServer.TradeServer
{
    public class TradingEngineHealthCheck : IHealthCheck
    {
        private readonly ILogger<TradingEngineHealthCheck> _logger;
        private readonly TradingEngineService _tradingEngine;

        public TradingEngineHealthCheck(ILogger<TradingEngineHealthCheck> logger, TradingEngineService tradingEngine)
        {
            _logger = logger;
            _tradingEngine = tradingEngine;
        }

        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            try
            {
                var isHealthy = _tradingEngine.IsHealthy();
                
                if (isHealthy)
                {
                    return Task.FromResult(HealthCheckResult.Healthy("Trading engine is running normally"));
                }
                else
                {
                    return Task.FromResult(HealthCheckResult.Unhealthy("Trading engine is not running"));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Health check failed");
                return Task.FromResult(HealthCheckResult.Unhealthy("Health check failed", ex));
            }
        }
    }
}
