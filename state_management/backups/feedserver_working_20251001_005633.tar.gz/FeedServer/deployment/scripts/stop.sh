#!/bin/bash

# TradeServer Stop Script
# This script stops the SignalEngine trading application

set -e

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Stopping SignalEngine..."

# Find and kill SignalEngine processes
PIDS=$(pgrep -f "SignalEngine" || true)

if [ -z "$PIDS" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] No SignalEngine processes found"
    exit 0
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Found SignalEngine processes: $PIDS"

# Try graceful shutdown first
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Attempting graceful shutdown..."
for PID in $PIDS; do
    if kill -TERM "$PID" 2>/dev/null; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Sent SIGTERM to process $PID"
    fi
done

# Wait for processes to terminate
sleep 5

# Check if processes are still running
REMAINING_PIDS=$(pgrep -f "SignalEngine" || true)

if [ -n "$REMAINING_PIDS" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Processes still running, forcing shutdown..."
    for PID in $REMAINING_PIDS; do
        if kill -KILL "$PID" 2>/dev/null; then
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] Sent SIGKILL to process $PID"
        fi
    done
    sleep 2
fi

# Final check
FINAL_PIDS=$(pgrep -f "SignalEngine" || true)

if [ -z "$FINAL_PIDS" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] SignalEngine stopped successfully"
    exit 0
else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: Failed to stop some processes: $FINAL_PIDS"
    exit 1
fi
