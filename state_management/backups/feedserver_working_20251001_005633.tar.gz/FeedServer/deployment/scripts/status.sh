#!/bin/bash

# TradeServer Status Script
# This script checks the status of the SignalEngine trading application

set -e

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Checking SignalEngine status..."

# Check for running processes
PIDS=$(pgrep -f "SignalEngine" || true)

if [ -z "$PIDS" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] STATUS: SignalEngine is NOT running"
    exit 1
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S')] STATUS: SignalEngine is RUNNING"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Process IDs: $PIDS"

# Show process details
for PID in $PIDS; do
    if [ -d "/proc/$PID" ]; then
        START_TIME=$(stat -c %Y "/proc/$PID" 2>/dev/null || echo "unknown")
        if [ "$START_TIME" != "unknown" ]; then
            START_DATE=$(date -d "@$START_TIME" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "unknown")
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] Process $PID started at: $START_DATE"
        fi
        
        # Show memory usage
        if [ -f "/proc/$PID/status" ]; then
            MEM_KB=$(grep "VmRSS:" "/proc/$PID/status" 2>/dev/null | awk '{print $2}' || echo "unknown")
            if [ "$MEM_KB" != "unknown" ]; then
                MEM_MB=$((MEM_KB / 1024))
                echo "[$(date '+%Y-%m-%d %H:%M:%S')] Process $PID memory usage: ${MEM_MB} MB"
            fi
        fi
    fi
done

# Check log file for recent activity
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$(dirname "$SCRIPT_DIR")"
LOG_FILE="$APP_DIR/logs/runtime.log"

if [ -f "$LOG_FILE" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Recent log entries:"
    tail -5 "$LOG_FILE" 2>/dev/null | while read -r line; do
        echo "  $line"
    done
else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] No log file found at: $LOG_FILE"
fi

# Check health endpoint if available (assuming default port 8080)
if command -v curl >/dev/null 2>&1; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Checking health endpoint..."
    if curl -s -f "http://localhost:8080/health" >/dev/null 2>&1; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Health endpoint: HEALTHY"
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Health endpoint: NOT RESPONDING"
    fi
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Status check completed"
exit 0
