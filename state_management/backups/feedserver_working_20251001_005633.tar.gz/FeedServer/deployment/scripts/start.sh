#!/bin/bash

# TradeServer Start Script
# This script starts the SignalEngine trading application

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$(dirname "$SCRIPT_DIR")"
BIN_DIR="$APP_DIR/bin"
LOG_DIR="$APP_DIR/logs"
CONFIG_DIR="$APP_DIR/config"

# Ensure log directory exists
mkdir -p "$LOG_DIR"

# Set environment variables
export ASPNETCORE_ENVIRONMENT="${ASPNETCORE_ENVIRONMENT:-Production}"
export DOTNET_ENVIRONMENT="${DOTNET_ENVIRONMENT:-Production}"

# Change to application directory
cd "$BIN_DIR"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting SignalEngine..."
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Environment: $ASPNETCORE_ENVIRONMENT"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Working Directory: $(pwd)"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Log Directory: $LOG_DIR"

# Check if application exists
if [ ! -f "SignalEngine" ] && [ ! -f "SignalEngine.dll" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: SignalEngine application not found in $BIN_DIR"
    exit 1
fi

# Start the application
if [ -f "SignalEngine" ]; then
    # Native executable
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting native executable..."
    ./SignalEngine 2>&1 | tee "$LOG_DIR/runtime.log"
else
    # .NET application
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting .NET application..."
    dotnet SignalEngine.dll 2>&1 | tee "$LOG_DIR/runtime.log"
fi
