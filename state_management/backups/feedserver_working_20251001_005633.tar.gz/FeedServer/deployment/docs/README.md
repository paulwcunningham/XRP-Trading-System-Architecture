# TradeServer - Low-Latency Trading System

A high-performance, low-latency trading system built with .NET 8, featuring statistical arbitrage, risk management, and real-time signal processing.

## Architecture Overview

The TradeServer is designed as a modular, high-performance trading system with the following key components:

### Core Components

- **SignalEngine**: Main application entry point and orchestration
- **Risk Management**: Multi-layer risk validation with circuit breakers
- **Signal Processing**: Real-time signal quality validation and filtering
- **Trading Strategies**: Statistical arbitrage and triangular arbitrage
- **Performance Optimization**: Low-latency processing with memory pooling

### Key Features

- **7-Layer Risk Management**: Comprehensive risk validation including kill switches, position limits, and circuit breakers
- **Statistical Arbitrage**: Mean reversion strategies with z-score analysis
- **Signal Quality Validation**: Real-time signal filtering and duplicate detection
- **Performance Monitoring**: Sub-millisecond latency tracking and optimization
- **Health Monitoring**: Built-in health checks and performance metrics

## Quick Start

### Prerequisites

- .NET 8.0 SDK
- Redis (optional, for distributed caching)
- Linux/Windows environment

### Local Development

1. **Clone and Build**
   ```bash
   git clone <repository-url>
   cd TradeServer/project/SignalEngine
   dotnet restore
   dotnet build
   ```

2. **Run the Application**
   ```bash
   dotnet run
   ```

3. **Run with Production Configuration**
   ```bash
   export ASPNETCORE_ENVIRONMENT=Production
   dotnet run
   ```

### Docker Deployment (Development Only)

```bash
# Build image
docker build -t tradeserver .

# Run container
docker run -p 8080:8080 tradeserver
```

**Note**: For production deployments, use native compilation for optimal latency performance.

## Configuration

### Environment Variables

- `ASPNETCORE_ENVIRONMENT`: Set to `Production` for production deployment
- `REDIS_CONNECTION_STRING`: Redis connection string for production
- `REDIS_PASSWORD`: Redis password for production

### Configuration Files

- `appsettings.json`: Development configuration
- `appsettings.Production.json`: Production configuration with optimized settings

### Key Configuration Sections

#### Risk Settings
```json
{
  "Risk": {
    "KillSwitch": false,
    "MaxNotionalPerOrder": 50000,
    "MaxOrdersPerMinutePerSymbol": 60,
    "SignalTtlMs": 150
  }
}
```

#### Performance Settings
```json
{
  "Performance": {
    "MaxConcurrentProcessing": 10,
    "MessageBufferSize": 1000,
    "EnableBatchProcessing": true,
    "EnableParallelProcessing": true
  }
}
```

## Deployment

### Production Deployment

The system includes automated CI/CD pipeline with GitHub Actions:

1. **Automated Build**: Compiles and tests the application
2. **Deployment Package**: Creates deployment artifacts with scripts
3. **Runtime Logging**: Captures application logs for analysis
4. **Health Monitoring**: Monitors application health and performance

### Deployment Structure

```
deployment/
├── bin/                    # Application binaries
├── config/                 # Configuration files
├── scripts/               # Deployment scripts
│   ├── start.sh          # Start application
│   ├── stop.sh           # Stop application
│   └── status.sh         # Check status
├── logs/                  # Runtime logs
└── deployment-info.json   # Build information
```

### Manual Deployment

1. **Build Release**
   ```bash
   dotnet publish --configuration Release --output ./publish
   ```

2. **Deploy to Server**
   ```bash
   # Copy files to server
   scp -r publish/ user@server:/opt/tradeserver/
   
   # Start application
   ssh user@server "cd /opt/tradeserver && ./SignalEngine"
   ```

### Systemd Service (Linux)

Create `/etc/systemd/system/tradeserver.service`:

```ini
[Unit]
Description=TradeServer Application
After=network.target

[Service]
Type=notify
User=tradeserver
WorkingDirectory=/opt/tradeserver
ExecStart=/opt/tradeserver/SignalEngine
Restart=always
RestartSec=10
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=DOTNET_ENVIRONMENT=Production

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable tradeserver
sudo systemctl start tradeserver
sudo systemctl status tradeserver
```

## Monitoring and Logging

### Application Logs

- **Console Logging**: Real-time console output (development)
- **File Logging**: Structured logs to file (production)
- **Performance Logging**: Latency and throughput metrics
- **Risk Logging**: Risk validation events and rejections

### Health Checks

Access health status at: `http://localhost:8080/health`

### Performance Metrics

The application tracks:
- Signal processing latency (microseconds)
- Order generation throughput
- CPU and memory usage
- Error rates and circuit breaker status

## Development

### Project Structure

```
project/
├── SignalEngine/          # Main application
├── Config/               # Configuration classes
├── Models/               # Data models
├── Risk/                 # Risk management
├── Validation/           # Signal validation
├── Strategies/           # Trading strategies
├── Performance/          # Performance optimization
└── TradeServer/          # Core trading engine
```

### Adding New Strategies

1. Implement strategy in `Strategies/` folder
2. Register in `Program.cs`
3. Add configuration to `AppSettings`
4. Update strategy evaluation in `TradingEngineService`

### Testing

```bash
# Run tests
dotnet test

# Run with coverage
dotnet test --collect:"XPlat Code Coverage"
```

## Performance Optimization

### Low-Latency Features

- **Object Pooling**: Reduces garbage collection pressure
- **Batch Processing**: Optimizes throughput for high-volume scenarios
- **Parallel Processing**: Utilizes multiple CPU cores
- **Memory Optimization**: Minimizes allocations in hot paths

### Benchmarking

The system includes built-in performance monitoring:
- Sub-millisecond latency tracking
- Throughput measurement
- Resource utilization monitoring
- Performance regression detection

## Security Considerations

### Production Security

- **Sensitive Data**: API keys and secrets are masked in logs
- **Environment Variables**: Use environment variables for production secrets
- **Network Security**: Deploy behind firewall with restricted access
- **Authentication**: Implement proper authentication for production APIs

### Risk Management

- **Kill Switch**: Global emergency stop for all trading
- **Position Limits**: Per-symbol and global position limits
- **Rate Limiting**: Prevents excessive order generation
- **Circuit Breakers**: Automatic halt on repeated failures

## Troubleshooting

### Common Issues

1. **High Latency**
   - Check CPU usage and system load
   - Verify garbage collection settings
   - Review concurrent processing limits

2. **Memory Issues**
   - Enable memory optimization in configuration
   - Monitor object pool usage
   - Check for memory leaks in custom code

3. **Connection Issues**
   - Verify network connectivity
   - Check exchange API credentials
   - Review rate limiting settings

### Log Analysis

Key log patterns to monitor:
- `[RiskEngine]`: Risk validation events
- `[TradingEngine]`: Core trading operations
- `[Performance]`: Performance warnings
- `ERROR`: Application errors requiring attention

## Support and Maintenance

### Monitoring Checklist

- [ ] Application health status
- [ ] Performance metrics within acceptable ranges
- [ ] Error rates below threshold
- [ ] Risk limits properly configured
- [ ] Log files rotating properly

### Regular Maintenance

- Monitor disk space for log files
- Review and update risk parameters
- Analyze performance trends
- Update dependencies and security patches

## License

This project is proprietary software. All rights reserved.

## Contact

For technical support and questions, please contact the development team.
